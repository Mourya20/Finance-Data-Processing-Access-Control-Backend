const request = require('supertest');
const app = require('../src/app');

test('Register user', async () => {
  const res = await request(app).post('/auth/register').send({
    email: `test${Date.now()}@test.com`,
    password: "123456",
    role: "ADMIN"
  });

  console.log(res.body); // debug

  expect(res.statusCode).toBe(201);
});