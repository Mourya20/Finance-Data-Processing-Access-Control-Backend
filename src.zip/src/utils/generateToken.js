const jwt = require('jsonwebtoken');
module.exports = (user) => jwt.sign(user, 'secret', { expiresIn: '1d' });
