require('dotenv').config();
const express = require('express');
const rateLimit = require('./middleware/rateLimit');
const app = express();

app.use(express.json());
app.use(rateLimit);

app.use('/auth', require('./routes/auth.routes'));
app.use('/records', require('./routes/record.routes'));
app.use('/dashboard', require('./routes/dashboard.routes'));
app.use((err, req, res, next) => {
  console.error(err);
  res.status(500).json({ error: "Something went wrong" });
});
app.use((req, res, next) => {
  console.log(`${req.method} ${req.url}`);
  next();
});
app.use('/budget', require('./routes/budget.routes'));

app.get('/', (req, res) => {
  res.send(`
    <!DOCTYPE html>
    <html lang="en">
    <head>
      <meta charset="UTF-8">
      <meta name="viewport" content="width=device-width, initial-scale=1.0">
      <title>Zorovyn API - Status</title>
      <style>
        :root {
          --primary: #6366f1;
          --bg: #0f172a;
          --card: #1e293b;
        }
        body {
          font-family: 'Inter', system-ui, -apple-system, sans-serif;
          background: var(--bg);
          color: white;
          display: flex;
          align-items: center;
          justify-content: center;
          height: 100vh;
          margin: 0;
        }
        .container {
          background: var(--card);
          padding: 2rem;
          border-radius: 1rem;
          text-align: center;
          box-shadow: 0 10px 15px -3px rgba(0, 0, 0, 0.1);
          border: 1px solid rgba(255, 255, 255, 0.1);
        }
        h1 { margin-bottom: 0.5rem; color: var(--primary); }
        p { color: #94a3b8; }
        .status {
          display: inline-block;
          padding: 0.5rem 1rem;
          background: rgba(34, 197, 94, 0.2);
          color: #4ade80;
          border-radius: 9999px;
          font-size: 0.875rem;
          margin-top: 1rem;
        }
      </style>
    </head>
    <body>
      <div class="container">
        <h1>Zorovyn API</h1>
        <p>The backend server is running successfully.</p>
        <div class="status">● Online</div>
      </div>
    </body>
    </html>
  `);
});

module.exports = app;
